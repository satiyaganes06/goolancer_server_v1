<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Display Image</title>
</head>
<body>
    <h1>Display Image</h1>
    <img src="<?php echo e(asset($imagePath)); ?>" alt="Image">
</body>
</html>
<?php /**PATH /home8/goolance/goolancer_server_v1/resources/views/image_viewer.blade.php ENDPATH**/ ?>