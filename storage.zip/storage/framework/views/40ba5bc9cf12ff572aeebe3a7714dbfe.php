
<?php $__env->startSection('admin_content'); ?>
    <style>
        .searchLogo {
            background-color: aliceblue;
            border: 0 !important;
            border-radius: 20px 0 0 20px !important;
        }

        .searchField {
            border: 0 !important;
            border-radius: 0 20px 20px 0 !important;
        }
    </style>
    <div class="page-content">

        

        <div class="row">
            <div class="col-md-12 stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h3 class="text-center pb-4">Add Expert</h3>
                        <form class="forms-sample"  action="<?php echo e(route('admin.addInHouseExperts')); ?>" method="POST">
                           
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="mb-3">
                                        <label
                                            class="form-label">First
                                            Name</label>
                                        <input type="text"
                                            class="form-control"
                                            name="first_name"
                                            placeholder="John">
                                    </div>
                                </div><!-- Col -->
                                <div class="col-sm-6">
                                    <div class="mb-3">
                                        <label
                                            class="form-label">Last
                                            Name</label>
                                        <input type="text"
                                            class="form-control"
                                            name="last_name"
                                            placeholder="Doe">
                                    </div>
                                </div><!-- Col -->
                            </div><!-- Row -->
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="mb-3">
                                        <label
                                            class="form-label">NRIC</label>
                                        <input type="text"
                                            class="form-control"
                                            name="nric"
                                            placeholder="01038927382823">
                                    </div>
                                </div><!-- Col -->
                                <div class="col-sm-6">
                                    <div class="mb-3">
                                        <label
                                            class="form-label">Role</label>
                                        <input type="text"
                                            class="form-control"
                                            value="In-House Expert"
                                            disabled
                                            placeholder="">
                                    </div>
                                </div><!-- Col -->
                               
                            </div><!-- Row -->
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="mb-3">
                                        <label
                                            class="form-label">Email
                                            address</label>
                                        <input type="email"
                                            class="form-control"
                                            name="email"    
                                            placeholder="johndoe@gmail.com">
                                    </div>
                                </div><!-- Col -->
                                <div class="col-sm-6">
                                    <div class="mb-3">
                                        <label
                                            class="form-label">Password</label>
                                        <input type="password"
                                            class="form-control"
                                            autocomplete="off"
                                            name="password">
                                    </div>
                                </div><!-- Col -->
                            </div><!-- Row -->

                            <div class="row">
                                
                                <div class="col-sm-12">
                                    <div class="mb-3">
                                        <label
                                            class="form-label">Confirm Password</label>
                                        <input type="password"
                                            class="form-control"
                                            autocomplete="off"
                                            name="confirm_password"
                                            placeholder="">
                                    </div>
                                </div><!-- Col -->
                            </div>

                            <div class="d-grid gap-2 pt-5">
                                <?php echo csrf_field(); ?>
                                <button type="submit"  class="btn btn-primary  text-light"
                                    data-mdb-ripple-init><b>Register</b></button>
                            </div>
                        </form>
                        
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\goolancer_server_v1\resources\views/admin/add_in_house_expert.blade.php ENDPATH**/ ?>