<footer class="footer d-flex flex-column flex-md-row align-items-center justify-content-center px-4 py-3 border-top small">
    <p class="text-muted mb-1 mb-md-0">Copyright © 2023 <a href="#" target="_blank">GooLancer</a>.</p>

</footer>
<?php /**PATH C:\laragon\www\goolancer_server_v1\resources\views/admin/body/footer.blade.php ENDPATH**/ ?>