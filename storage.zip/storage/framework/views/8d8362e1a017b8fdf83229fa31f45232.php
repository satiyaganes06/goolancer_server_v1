
<?php $__env->startSection('admin_content'); ?>
    <style>
        .searchLogo {
            background-color: aliceblue;
            border: 0 !important;
            border-radius: 20px 0 0 20px !important;
        }

        .searchField {
            border: 0 !important;
            border-radius: 0 20px 20px 0 !important;
        }
    </style>
    <div class="page-content">

        <div class="row">
            <div class="col-5 col-md-3 pe-0">
                <div class="nav nav-tabs nav-tabs-vertical" id="v-tab" role="tablist" aria-orientation="vertical">
                    <a class="nav-link active" id="v-init-tab" data-bs-toggle="pill" href="#v-init" role="tab"
                        aria-controls="v-init" aria-selected="true">Initial Payment</a>
                    <a class="nav-link" id="v-progress-tab" data-bs-toggle="pill" href="#v-progress" role="tab"
                        aria-controls="v-progress" aria-selected="false">Progress Order</a>
                    <a class="nav-link" id="v-complete-tab" data-bs-toggle="pill" href="#v-complete" role="tab"
                        aria-controls="v-complete" aria-selected="false">Complete Payment</a>
                    <a class="nav-link" id="v-delivery-tab" data-bs-toggle="pill" href="#v-delivery" role="tab"
                        aria-controls="v-delivery" aria-selected="false">Delivery</a>
                    <a class="nav-link" id="v-review-tab" data-bs-toggle="pill" href="#v-review" role="tab"
                        aria-controls="v-review" aria-selected="false">Review & Rating</a>
                </div>
            </div>
            <div class="col-7 col-md-9 ps-0">
                <div class="tab-content tab-content-vertical border p-3" id="v-tabContent">

                    
                    <div class="tab-pane fade show active" id="v-init" role="tabpanel" aria-labelledby="v-init-tab">
                        <h3 class="mb-1">Initial Payment</h3>
                        

                        <label class="form-label mt-3">Payment Status:</label>
                        <?php if($jobPaymentInitial != null): ?>
                            <?php if($jobPaymentInitial->jp_int_status == 0): ?>
                                <input class="form-control" value="Pending" disabled />
                            <?php elseif($jobPaymentInitial->jp_int_status == 1): ?>
                                <input class="form-control" value="Accept" disabled />
                            <?php elseif($jobPaymentInitial->jp_int_status == 2): ?>
                                <input class="form-control" value="Reject" disabled />
                            <?php endif; ?>

                            <br>

                            <div>
                                <p class="form-label">Payment Receipt:</p>
                                <a
                                    href="http://goolancer.online/user/displayImage/<?php echo e($jobPaymentInitial->jp_var_receipt); ?>"><i
                                        class="fs-6 text-dark link-icon" data-feather="file-text"
                                        style="height: 20"></i></a>
                            </div>
                        <?php else: ?>
                            <input class="form-control" value="Pending" disabled />
                        <?php endif; ?>
                    </div>

                    
                    <div class="tab-pane fade" id="v-progress" role="tabpanel" aria-labelledby="v-progress-tab">
                        <h3 class="mb-1">Progress Order Details</h3>
                        
                        <hr>
                        <?php if($jobResults != null): ?>
                            <?php $__currentLoopData = $jobResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobResult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="m-3">
                                    <p class="pb-3"><?php echo e($jobResult->jr_txt_description); ?></p>

                                    <?php if($jobResult->fileURL != null): ?>
                                        <?php $__currentLoopData = $jobResult->fileURL; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobResultFile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $extension = pathinfo(
                                                    $jobResultFile->jrf_files_path,
                                                    PATHINFO_EXTENSION,
                                                );
                                            ?>

                                            <?php if($extension == 'pdf'): ?>
                                                <a
                                                    href="http://goolancer.online/user/displayImage/<?php echo e($jobResultFile->jrf_files_path); ?>"><img
                                                        src="https://img.freepik.com/premium-vector/pdf-file-icon-flat-design-graphic-illustration-vector-pdf-icon_676691-2007.jpg?w=740"
                                                        alt="" height="150"></a>
                                            <?php else: ?>
                                                <a
                                                    href="http://goolancer.online/user/displayImage/<?php echo e($jobResultFile->jrf_files_path); ?>"><img
                                                        src="http://goolancer.online/user/displayImage/<?php echo e($jobResultFile->jrf_files_path); ?>"
                                                        alt="" height="150"></a>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <?php endif; ?>

                                </div>

                                <hr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="p-5 h-50 text-center">
                                <p>No progress</p>
                            </div>
                        <?php endif; ?>
                    </div>

                    
                    <div class="tab-pane fade" id="v-complete" role="tabpanel" aria-labelledby="v-complete-tab">
                        <h3 class="mb-1">Complete Payment</h3>
                        

                        <label class="form-label mt-3">Payment Status:</label>
                        <?php if($jobPaymentComplete != null): ?>
                            <?php if($jobPaymentComplete->jp_int_status == 0): ?>
                                <input class="form-control" value="Pending" disabled />
                            <?php elseif($jobPaymentComplete->jp_int_status == 1): ?>
                                <input class="form-control" value="Accept" disabled />
                            <?php elseif($jobPaymentComplete->jp_int_status == 2): ?>
                                <input class="form-control" value="Reject" disabled />
                            <?php endif; ?>

                            <br>

                            <div>
                                <p class="form-label">Payment Receipt:</p>
                                <a
                                    href="http://goolancer.online/user/displayImage/<?php echo e($jobPaymentComplete->jp_var_receipt); ?>"><i
                                        class="fs-6 text-dark link-icon" data-feather="file-text"
                                        style="height: 20"></i></a>
                            </div>
                        <?php else: ?>
                        <div class="p-5 h-50 text-center">
                            <p>No Payment</p>
                        </div>
                        <?php endif; ?>
                    </div>

                    
                    <div class="tab-pane fade" id="v-delivery" role="tabpanel" aria-labelledby="v-delivery-tab">
                        <h3 class="mb-1">Delivery</h3>
                        <hr>
                        <?php if(count($jobResultsDeliverys) > 0): ?>


                            <div class="m-3">
                                <p class="pb-3"><?php echo e($jobResultsDeliverys[0]->jr_txt_description); ?></p>

                                <?php if($jobResultsDeliverys[0]->fileURL != null): ?>
                                    <?php $__currentLoopData = $jobResultsDeliverys[0]->fileURL; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobResultFile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $extension = pathinfo($jobResultFile->jrf_files_path, PATHINFO_EXTENSION);
                                        ?>

                                        <?php if($extension == 'pdf'): ?>
                                            <a
                                                href="http://goolancer.online/user/displayImage/<?php echo e($jobResultFile->jrf_files_path); ?>"><img
                                                    src="https://img.freepik.com/premium-vector/pdf-file-icon-flat-design-graphic-illustration-vector-pdf-icon_676691-2007.jpg?w=740"
                                                    alt="" height="150"></a>
                                        <?php else: ?>
                                            <a
                                                href="http://goolancer.online/user/displayImage/<?php echo e($jobResultFile->jrf_files_path); ?>"><img
                                                    src="http://goolancer.online/user/displayImage/<?php echo e($jobResultFile->jrf_files_path); ?>"
                                                    alt="" height="150"></a>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <?php endif; ?>

                            </div>

                            <hr>
                        <?php else: ?>
                            <div class="p-5 h-50 text-center">
                                <p>No progress</p>
                            </div>
                        <?php endif; ?>
                    </div>

                    
                    <div class="tab-pane fade" id="v-review" role="tabpanel" aria-labelledby="v-review-tab">
                        <h3 class="mb-1">Review & Rating</h3>
               

                        <?php if($jobUserRating != null): ?>
                        <div class="d-flex align-items-start mt-4">
                            <img src="http://goolancer.online/user/displayImage/<?php echo e($clientDetails->up_var_pic_first_name); ?>" class="align-self-start wd-50 wd-sm-100 me-3 rounded-5" alt="...">
                            <div>
                                <h5 class="mb-2"><?php echo e($clientDetails->up_var_first_name); ?> <?php echo e($clientDetails->up_var_last_name); ?></h5>
                                <p><?php echo e($jobUserRating->jur_txt_comment); ?></p>
                            </div>

                            
                        </div>

                        <div class="d-flex justify-content-end">
                            
                                <i class="link-icon text-warning pr-2" data-feather="star"></i>
                                <p class="fs-4"><?php echo e($jobUserRating->jur_rating_point); ?></p>
                        </div>

                        <hr>
                        <?php else: ?>
                        <div class="p-5 h-50 text-center">
                            <p>No rating</p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\goolancer_server_v1\resources\views/admin/view_order.blade.php ENDPATH**/ ?>