<?php $__env->startSection('admin_content'); ?>
    <style>
        .searchLogo {
            background-color: aliceblue;
            border: 0 !important;
            border-radius: 20px 0 0 20px !important;
        }

        .searchField {
            border: 0 !important;
            border-radius: 0 20px 20px 0 !important;
        }
    </style>
    <div class="page-content">

        <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
            <div>
                <h4 class="mb-3 mb-md-0">Client Management</h4>
            </div>

            <div class="col-md-12 grid-margin stretch-card mt-3">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <h6 class="card-title">Client List</h6>
                            <form class="d-flex input-group w-auto mr-4" action="" method="GET">

                                <span class="input-group-text searchLogo bg-light" id="search-addon">
                                    <button type="submit" class="border-0 bg-light"><i class="link-icon"
                                            data-feather="search"></i></button>
                                </span>

                                <input type="search" id="form1" class="form-control searchField bg-light" name="searchTerm"
                                    placeholder="Search" aria-label="Search" aria-describedby="search-addon" onkeyup="myFunction()"/>

                            </form>
                        </div>
                        <p class="text-muted mb-3">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>BIL</th>
                                        <th>FULL NAME</th>
                                        <th>NRIC</th>
                                        <th>EMAIL</th>
                                        <th>ACTION</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $i = 0;
                                    ?>
                                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $i++;
                                        ?>
                                        <tr>
                                            <th class="pt-4"><?php echo e($i); ?></th>
                                            <td class="d-flex align-items-center"> <img
                                                    src="http://goolancer.online/user/displayImage/<?php echo e($client->up_var_pic_first_name); ?>"
                                                    alt="image">
                                                <div style="width:10px"></div> <?php echo e($client->up_var_first_name); ?>

                                                <?php echo e($client->up_var_last_name); ?>

                                            </td>
                                            <td>
                                                <p class="pt-1"><?php echo e($client->up_var_nric); ?></p>
                                            </td>
                                            <td class="pt-3"><?php echo e($client->up_var_email_contact); ?></td>
                                            <td>
                                                <div class="d-flex ">
                                                    <a href=" <?php echo e(route('admin.viewUserAccountInfo', ['id' => $client->up_int_ref, 'role' => 0])); ?>"><i class="fs-6 " class="link-icon" data-feather="eye"
                                                            style="height: 20"></i></a>
                                                    <div style="width:10px"></div>

                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </tbody>
                            </table>

                            <div class="mt-3">
                                <?php echo e($clients->links('pagination::bootstrap-5')); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-12 grid-margin stretch-card mt-3">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <h6 class="card-title">Expert List</h6>
                            <div class="d-flex">
                                <form class="d-flex input-group w-auto mr-4" action="" method="GET">

                                    <span class="input-group-text searchLogo bg-light" id="search-addon">
                                        <button type="submit" class="border-0 bg-light"><i class="link-icon"
                                                data-feather="search"></i></button>
                                    </span>
    
                                    <input type="search" id="form2" class="form-control searchField bg-light" name="searchTerm"
                                        placeholder="Search" aria-label="Search" aria-describedby="search-addon" onkeyup="myFunction2()"/>
    
                                </form>
                                
                                <a href="<?php echo e(route('admin.addInHouseExpertView')); ?>"><button class="btn btn-primary mx-2 rounded-3">+ In-House</button></a>
                                
                            </div>
                        </div>
                        <p class="text-muted mb-3">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>BIL</th>
                                        <th>FULL NAME</th>
                                        <th>EMAIL</th>
                                        <th>Role</th>
                                        <th>ACTION</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $i = 0;
                                    ?>
                                    <?php $__currentLoopData = $experts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $i++;
                                        ?>
                                        <tr>
                                            <th class="pt-4">1</th>
                                            <td class="d-flex align-items-center"> <img
                                                    src="http://goolancer.online/user/displayImage/<?php echo e($expert->up_var_pic_first_name); ?>"
                                                    alt="image">
                                                <div style="width:10px"></div> <?php echo e($expert->up_var_first_name); ?>

                                                <?php echo e($expert->up_var_last_name); ?>

                                            </td>
                                            <td class="pt-3">
                                                <p><?php echo e($expert->up_var_email_contact); ?></p>
                                            </td>
                                            <td class="pt-3"><span class="badge rounded-pill bg-success">
                                                    <?php if($expert->up_int_role == 2): ?>
                                                        In-House
                                                    <?php else: ?>
                                                        Expert
                                                    <?php endif; ?>

                                                </span></td>
                                            <td>
                                                <div class="d-flex ">
                                                    <a href="<?php echo e(route('admin.viewUserAccountInfo', ['id' => $expert->up_int_ref, 'role' => 1])); ?>"><i class="fs-6 " class="link-icon" data-feather="eye"
                                                            style="height: 20"></i></a>
                                                    
                                                    <div style="width:10px"></div>
                                                    
                                                    

                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </tbody>
                            </table>

                            <div class="mt-3">
                                <?php echo e($experts->links('pagination::bootstrap-5')); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>



        </div>
    
    </div>
        <script>
            function myFunction() {
                var input, filter, table, tr, td, i, txtValue;
                input = document.getElementById("form1");
                filter = input.value.toUpperCase();
                table = document.getElementsByTagName("table")[0];
                tr = table.getElementsByTagName("tr");
                for (i = 0; i < tr.length; i++) {
                    td = tr[i].getElementsByTagName("td")[2]; // Change index to match the column you want to search
                    if (td) {
                        txtValue = td.textContent || td.innerText;
                        if (txtValue.toUpperCase().indexOf(filter) > -1) {
                            tr[i].style.display = "";
                        } else {
                            tr[i].style.display = "none";
                        }
                    }
                }
            }

            function myFunction2() {
                var input, filter, table, tr, td, i, txtValue;
                input = document.getElementById("form2");
                filter = input.value.toUpperCase();
                table = document.getElementsByTagName("table")[1];
                tr = table.getElementsByTagName("tr");
                for (i = 0; i < tr.length; i++) {
                    td = tr[i].getElementsByTagName("td")[2]; // Change index to match the column you want to search
                    if (td) {
                        txtValue = td.textContent || td.innerText;
                        if (txtValue.toUpperCase().indexOf(filter) > -1) {
                            tr[i].style.display = "";
                        } else {
                            tr[i].style.display = "none";
                        }
                    }
                }
            }
        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\goolancer_server_v1\resources\views/admin/user_account.blade.php ENDPATH**/ ?>