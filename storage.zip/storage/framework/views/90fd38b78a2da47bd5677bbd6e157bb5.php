<?php $__env->startSection('admin_content'); ?>
    <style>
        .searchLogo {
            background-color: aliceblue;
            border: 0 !important;
            border-radius: 20px 0 0 20px !important;
        }

        .searchField {
            border: 0 !important;
            border-radius: 0 20px 20px 0 !important;
        }
        .ellipse {
            white-space: nowrap;
            display: inline-block;
            overflow: hidden;
            text-overflow: ellipsis;
            text-align: justify
        }

        .two-lines {
            -webkit-line-clamp: 5;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            white-space: normal;
        }

        .width {
            width: auto;
        }
    </style>
    <div class="page-content">

        <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
            <div>
                <h4 class="mb-3 mb-md-0">Payment Approval</h4>
            </div>

            <div class="col-md-12 grid-margin stretch-card mt-3">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">

                            <form class="d-flex input-group w-auto mr-4" action="" method="GET">

                                <span class="input-group-text searchLogo bg-light" id="search-addon">
                                    <button type="submit" class="border-0 bg-light"><i class="link-icon"
                                            data-feather="search"></i></button>
                                </span>

                                <input type="search" id="form1" class="form-control searchField bg-light" name="searchTerm"
                                    placeholder="Search" aria-label="Search" aria-describedby="search-addon" onkeyup="myFunction()"/>

                            </form>
                        </div>
                        <p class="text-muted mb-3">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>BIL</th>
                                        <th>PAID BY (EMAIL)</th>
                                        <th>PAYMENT TYPE</th>
                                        <th>TRANSACTION DETAILS</th>
                                        <th>RECEIPT</th>
                                        <th>STATUS</th>
                                        <th>ACTION</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $i = 0;
                                    ?>
                                    <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $i++;
                                        ?>
                                        <tr>
                                            <th class=""><?php echo e($i); ?></th>
                                            <td > <p> <?php echo e($payment->up_var_email_contact); ?> </p> </td>
                                            <td >
                                                <span class="badge rounded-pill bg-success">
                                                    <?php if($payment->jp_int_type == 0): ?>
                                                        Initial Payment
                                                    <?php elseif($payment->jp_int_type == 1): ?>
                                                        Final Payment
                                                    <?php endif; ?>

                                                </span>
                                            </td>
                                            <td>
                                               <div>
                                                <p>Name: <?php echo e($payment->jp_var_acount_transfer_name); ?></p>
                                                <p>Amount: RM <?php echo e($payment->jp_double_account_transfer_amount); ?> <a href="" data-bs-toggle="tooltip" data-bs-placement="right" data-bs-title="RM <?php echo e($payment->br_double_price * 0.1); ?>"><i class="fs-6 text-secondary " class="link-icon" data-feather="dollar-sign"
                                                    style="height: 20"></i></a>
                                            <div style="width:10px"></div></p>
                                                <p>Payment Date: <?php echo e($payment->jp_date_account_transfer_date); ?></p>
                                               </div>
                                            </td>
                                            <td>
                                                <a href="http://goolancer.online/user/displayImage/<?php echo e($payment->jp_var_receipt); ?>"><i class="fs-6 text-dark link-icon"  data-feather="file-text"
                                                    style="height: 20"></i></a>
                                            </td>
                                            <td>
                                                <?php if($payment->jp_int_status == 0): ?>
                                                    <p class="text-warning">Pending</p>
                                                <?php elseif($payment->jp_int_status == 1): ?>
                                                    <p class="text-success">Approved</p>
                                                <?php else: ?>
                                                    <p class="text-danger">Rejected</p>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($payment->jp_int_status == 0): ?>
                                                    <div class="d-flex ">
                                                    <a href="<?php echo e(route('admin.approvePayment', ['id' => $payment->jp_int_ref, 'status' => 2, 'paymentType' => $payment->jp_int_type])); ?>"><i class="fs-6 text-danger " class="link-icon" data-feather="x"
                                                        style="height: 20"></i></a>
                                                <div style="width:10px"></div>
                                                    <a href="<?php echo e(route('admin.approvePayment', ['id' => $payment->jp_int_ref, 'status' => 1, 'paymentType' => $payment->jp_int_type])); ?>"><i class="fs-6 text-success" class="link-icon" data-feather="check"
                                                            style="height: 20"></i></a>
                                                    <div style="width:10px"></div>

                                                </div>
                                                <?php else: ?>
                                                    <p>-</p>
                                                <?php endif; ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </tbody>
                            </table>

                            <div class="mt-3">
                                <?php echo e($payments->links('pagination::bootstrap-5')); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>




        </div>

    </div>
        <script>
            function myFunction() {
                var input, filter, table, tr, td, i, txtValue;
                input = document.getElementById("form1");
                filter = input.value.toUpperCase();
                table = document.getElementsByTagName("table")[0];
                tr = table.getElementsByTagName("tr");
                for (i = 0; i < tr.length; i++) {
                    td = tr[i].getElementsByTagName("td")[0]; // Change index to match the column you want to search
                    if (td) {
                        txtValue = td.textContent || td.innerText;
                        if (txtValue.toUpperCase().indexOf(filter) > -1) {
                            tr[i].style.display = "";
                        } else {
                            tr[i].style.display = "none";
                        }
                    }
                }
            }

            function myFunction2() {
                var input, filter, table, tr, td, i, txtValue;
                input = document.getElementById("form2");
                filter = input.value.toUpperCase();
                table = document.getElementsByTagName("table")[1];
                tr = table.getElementsByTagName("tr");
                for (i = 0; i < tr.length; i++) {
                    td = tr[i].getElementsByTagName("td")[2]; // Change index to match the column you want to search
                    if (td) {
                        txtValue = td.textContent || td.innerText;
                        if (txtValue.toUpperCase().indexOf(filter) > -1) {
                            tr[i].style.display = "";
                        } else {
                            tr[i].style.display = "none";
                        }
                    }
                }
            }
        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\goolancer_server_v1\resources\views/admin/approval/payment_approval.blade.php ENDPATH**/ ?>