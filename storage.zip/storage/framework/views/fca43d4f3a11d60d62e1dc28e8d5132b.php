
<?php $__env->startSection('admin_content'); ?>
    <style>
        .searchLogo {
            background-color: aliceblue;
            border: 0 !important;
            border-radius: 20px 0 0 20px !important;
        }

        .searchField {
            border: 0 !important;
            border-radius: 0 20px 20px 0 !important;
        }

        .ellipse {
            white-space: nowrap;
            display: inline-block;
            overflow: hidden;
            text-overflow: ellipsis;
            text-align: justify
        }

        .two-lines {
            -webkit-line-clamp: 5;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            white-space: normal;
        }

        .width {
            width: auto;
        }

        .post_container {
            margin-top: 20px;
            min-height: 70vh;
            width: 40vw;
            overflow-y: scroll;
            overflow-x: hidden;
            border-radius: 30px;
            background-color: rgb(255, 255, 255);
        }

        input::-webkit-outer-spin-button,
        input::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        /* Firefox */
        input[type=number] {
            -moz-appearance: textfield;
        }
    </style>
    <div class="page-content">
        <div class="w-100">
            <h4 class="pb-4 text-center">Orders</h4>
        </div>

        <div id="servicesGrid" class="row row-cols-1 row-cols-md-4 g-4 mt-3 ">

            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div style="margin-right: 10px" class="bg-white p-3 rounded-3">
                    <div class="d-flex justify-content-between">
                        <?php if($order->jm_int_status == 0): ?>
                            <span class="badge rounded-pill bg-primary">
                                In-Progress

                            </span>
                        <?php elseif($order->jm_int_status == 1): ?>
                            <span class="badge rounded-pill bg-success">
                                Delivered

                            </span>
                        <?php elseif($order->jm_int_status == 2): ?>
                            <span class="badge rounded-pill bg-danger">

                                Rejected
                            </span>
                        <?php endif; ?>


                        <p style="color: #d3d3d3"><?php echo e(\Carbon\Carbon::parse($order->jm_ts_created_at)->diffForHumans()); ?></p>
                    </div>

                    <div class="d-flex justify-content-start align-items-center pt-4">
                        <img width="50" height="50"
                            src="http://goolancer.online/user/displayImage/<?php echo e($order->up_var_pic_first_name); ?>"
                            alt="image" style="border-radius: 50%;">


                        <p style="margin-left: 10px"><?php echo e($order->br_var_title); ?></p>
                    </div>
                    <p style="margin-top: 10px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                        <?php echo e($order->br_txt_desc); ?></p>

                    <hr>

                    <div class="d-flex justify-content-between pb-2">
                        <b>Delivery Time: </b>
                        <p><?php echo e($order->br_var_delivery_time); ?></p>

                    </div>

                    <div class="d-flex justify-content-between pb-2">
                        <b>Budget: </b>
                        <p>RM <?php echo e($order->br_double_price); ?></p>

                    </div>
                    <?php if($order->br_var_address != null): ?>
                        <div class="d-flex justify-content-between pb-2">


                            <b>Address: </b>
                            <p><?php echo e($order->br_var_address); ?>, <?php echo e($order->br_int_zip_code); ?>, <?php echo e($order->br_var_state); ?></p>

                        </div>
                    <?php endif; ?>

                    <div class="d-grid gap-2 pt-3">

                        <button id="refundSubmitBtn" class="btn btn-dark rounded-3  text-light" data-mdb-ripple-init> <a
                                href="<?php echo e(route('admin.viewOrderInfo', ['id' => $order->jm_int_ref])); ?>"><b
                                    class="text-light">View More</b></a></button>
                    </div>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>



    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\goolancer_server_v1\resources\views/admin/view_all_order.blade.php ENDPATH**/ ?>